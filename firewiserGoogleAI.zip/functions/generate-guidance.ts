// DEPRECATED: This functionality has been integrated into the core aiService. This file will be removed.
