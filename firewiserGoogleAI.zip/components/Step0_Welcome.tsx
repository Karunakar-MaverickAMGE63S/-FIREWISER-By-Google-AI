// DEPRECATED: This component has been removed from the application flow.
// The app now starts directly at the Step1_Input screen.
